=== Performance Optimisation ===
Contributors: nilesh912
Tags: performance, optimization, cache, minify, image optimisation
Requires at least: 6.2
Requires PHP: 7.4
Tested up to: 6.9
Stable tag: 1.6.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Lightweight performance toolkit: cache, file minification, WebP/AVIF conversion, and Core Web Vitals tools with safe defaults.

== Description ==

Performance Optimisation helps you speed up your site with cache management, JavaScript and CSS minification, image conversion (WebP and AVIF), lazy loading, preload hints, and a modern admin UI. It is designed to stay **off by default** for aggressive options (defer/delay JS, WooCommerce asset removal, server rules) so you can enable features gradually and test as you go—similar to how you would tune Autoptimize or a caching stack, but with a focused, dashboard-first workflow.

**Why use this plugin?**

 - **Clear scope:** One place for cache stats, file optimisation, images, preload, and tools—without bundling unrelated features.
 - **Safety-first UX:** Advanced toggles show warnings; WooCommerce-related options remind you to test cart and checkout.
 - **Core Web Vitals & PageSpeed:** Lazy loading, minification, preconnect/prefetch, and image formats help real-world metrics—not just a higher score on a single lab test.

**Features:**

 - Dashboard with an overview of cache, JavaScript, CSS, and image optimisation status.
 - Cache management tools, including size display and a "Clear Cache" button.
 - JavaScript & CSS Optimization: Minify, combine, defer/delay (opt-in), and exclude specific files.
 - Core Tweaks: Safely disable Core bloat (Emojis, Embeds, Dashicons, XML-RPC, Heartbeat API).
 - Image optimization: Convert images to WebP and AVIF formats.
 - Preload settings for cache, fonts, DNS, and images.
 - Advanced lazy loading options.
 - Database Optimization: Clean database bloat manually or schedule automated cleanups (Daily/Weekly/Monthly) with granular control over post revisions.
 - **Enterprise Redis Support:** High-availability Object Cache with Sentinel, Cluster, and TLS/SSL support.
 - **Performance Monitor:** High-precision local telemetry for Core Web Vitals and network diagnostics.
 - **System Info Dashboard:** Real-time environment diagnostic tool for PHP, DB, and WordPress.
 - **Import/export** plugin settings.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/performance-optimisation` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Configure the settings via the **Performance Optimisation** menu in the WordPress admin panel.

== Usage ==

1. **Dashboard Overview**  
 - View cache size and clear cache.  
 - Check the number of minified JavaScript and CSS files.  
 - Monitor image optimisation (WebP/AVIF status).  
 - Review recent plugin activities.  

2. **File Optimization Settings**  
 - Minify JavaScript, CSS, and HTML.  
 - Combine CSS and exclude specific files.  
 - Defer and delay JavaScript loading.  
 - **Core Tweaks:** Disable emojis, embeds, XML-RPC, and control Heartbeat limits.

3. **Preload Settings**  
 - Enable cache preloading.  
 - Preconnect to origins and prefetch DNS.  
 - Preload fonts, CSS, and images.  

4. **Image Optimisation Settings**  
 - Lazy load images with SVG placeholders.  
 - Convert images to WebP/AVIF formats and exclude specific images.  
 - Preload feature images for selected post types.  

5. **Database Cleanup**  
 - Schedule automatic cleanup for revisions, auto-drafts, and transients.
 - Keep recent revisions based on age or maximum count.
 - Clean all overhead in one click.

6. **Tools**  
 - Import/export plugin settings for quick setup.

== Composer Libraries ==

This plugin uses the following composer libraries:

 - `voku/html-min` - For HTML minification.
 - `matthiasmullie/minify` - For JavaScript and CSS minification.

Composer configuration:

`
{
	"name": "nilesh/performance-optimisation",
	"description": "A package for performance optimization, including HTML minification and code minification tools.",
	"license": "GPL-2.0-or-later",
	"authors": [
		{
			"name": "nilesh",
			"email": "nilesh.kanzariya912@gmail.com",
			"homepage": "https://github.com/nilesh32236"
		}
	],
	"require": {
		"voku/html-min": "^4.5",
		"matthiasmullie/minify": "^1.3",
		"woocommerce/action-scheduler": "^3.8"
	},
	"extra": {
		"cleanup": {
			"dirs": ["bin", "tests", "docs"],
			"exclude": ["*.md", "*.yml", "*.xml", "tests", "docs"]
		}
	}
}
`

== Screenshots ==

1. **Dashboard**: Comprehensive overview of cache status, file optimization metrics, and recent activity log.
2. **File Optimization**: Minification settings for JavaScript, CSS, and HTML with Basic, Advanced, E-commerce, and Network tab configurations.
3. **Preload Settings**: Granular controls for cache warm-up, connection prediction (DNS/Preconnect), and critical asset prioritization (Fonts/CSS).
4. **Image Optimization**: Automated Next-Gen format conversion (WebP/AVIF), smart lazy loading with SVG placeholders, and intelligent LCP preloading.
5. **Database Optimization**: Safe manual and automated maintenance tools with advanced rules to keep specific historical revisions.
6. **Core Tweaks**: Advanced interface for controlling Heartbeat API frequency and stripping unneeded core WordPress bloat.
7. **Tools**: Simplified interface for exporting and importing your performance configurations across environments.

== Changelog ==

= 1.6.0 (2026-04-26) =
* New: PageSpeed Insights Integration — Audit your site performance directly from the WordPress dashboard using the official Google API.
* New: Nginx Support — Real-time generation of Nginx configuration rules for Gzip and Browser Caching.
* New: Advanced Telemetry Details — Real-time reporting of specific compression types (zstd, gzip, br) and raw Cache-Control headers.
* Improvement: Automatic `WP_CACHE` Fix — Automatically detects and repairs `define('WP_CACHE', false)` in `wp-config.php` during activation and hourly maintenance.
* Improvement: Modernized suggestion engine with high-precision actionable performance tips.
* Improvement: Enhanced Action Scheduler stability and infrastructure diagnostics.

= 1.5.1 (2026-04-23) =
* Improvement: Optimized `wppo_img_info` database option by disabling autoloading, significantly reducing memory usage on frontend page loads.
* Improvement: Implemented atomic write protection for image metadata to prevent redundant database operations during request shutdown.
* Fix: Consolidated performance guidelines in `bolt.md` to ensure consistent development patterns.

= 1.5.0 (2026-04-20) =
* New: Performance Monitor — High-precision local telemetry engine using raw cURL for granular network diagnostics (DNS, Connect, SSL, TTFB).
* New: System Info Dashboard — Real-time environment diagnostic tool providing detailed PHP, Database, WordPress, and Server metrics.
* New: Developer Mode — Advanced UI toggle for granular performance metrics and environment data.
* Improvement: Enhanced SSRF protection for local telemetry scans.
* Improvement: Modernized UI with dynamic WordPress admin color scheme adaptation using `color-mix()`.

= 1.4.0 (2026-04-18) =
* New: Enterprise Redis Object Cache support including Sentinel, Cluster, and TLS/SSL encryption modes.
* New: Atomic, batched processing for database cleanup and cron tasks to ensure stability on large-scale sites.
* New: Upgraded Design System v2.1 with modular components (FeatureCard, FeatureHeader, SwitchField) and optimized Sass architecture.
* New: Real-time status reporting on the dashboard for background optimization visibility.
* Improvement: Hardened security architecture with AJAX-based nonce resilience and DoS protection for image conversion.
* Improvement: Standardized REST API permission callbacks and input sanitization for enterprise compliance.
* Fix: Resolved structural regressions in REST cleanup controllers and improved reliability of revision management.

= 1.3.0 (2026-04-15) =
* New: Core Tweaks section to remove WordPress bloat (Emojis, Embeds, Dashicons) and control Heartbeat limits.
* New: Active WP-Cron scheduling for Database cleanups (Daily, Weekly, Monthly) with precise age/revision limits.
* New: Injected `fetchpriority` support to preload links for faster asset transmission.
* New: Implemented an active MutationObserver to track and lazy-load dynamically generated DOM content.
* New: Extended server-level cache expiration and Deflate/Gzip compression rules within `.htaccess`.
* New: Added logic to exclude specific self-hosted videos from lazy-loading routines.
* Improvement: Automatically inject `font-display: swap` into CSS payloads to eliminate render-blocking text.
* Improvement: Substantially refined UI aesthetics by migrating to native WP CSS variables and expanding component descriptions.
* Improvement: Added logic toggles to conditionally skip heavy HTML, CSS, and JS minification overhead.
* Fix: Mitigated false-positive SQL placeholder warnings (`WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare`) in database garbage collection routines.

= 1.2.3 (2026-04-14) =
* Fix: Resolved fatal error where `Advanced_Cache_Handler` was not found during activation or admin notice checks.
* Performance: Refactored `Advanced_Cache_Handler` to use lazy loading ("require when needed") to reduce memory footprint.
* Fix: Shortened plugin short description to meet WordPress.org's 150-character limit.

= 1.2.1 (2026-04-14) =
* Fix: Implemented handle whitelisting in Metabox to prevent unauthorized script/style handle persistence.
* Fix: Support parent directory locations for `wp-config.php` (core-mirroring behavior).
* Fix: Properly handle transient deletion and `WP_CACHE` constant guards during activation.
* Fix: Alignment and escaping in admin notices for WPCS compliance.
* Fix: Add `WP_CACHE` to wp-config.php when the constant was previously undefined (correct activation logic).
* Safety: `advanced-cache.php` includes a plugin marker; do not overwrite or delete another plugin’s drop-in.
* UX: Admin notices for foreign drop-in, wp-config issues, competing full-page cache plugins, and a short post-activation welcome notice.
* UI: Stronger warning when enabling WooCommerce asset removal.
* Docs: Expanded readme description, FAQ, and screenshot placeholders.
* Meta: Plugin header `Requires at least` now matches readme.txt (6.2).

= 1.2.0 (2026-04-13) =
* New: Automatic Gzip compression and browser caching for faster page loads.
* New: CDN support — serve static assets from your own CDN domain.
* New: Smarter cache clearing — related pages update automatically when you edit content.
* New: Safety prompts before deleting data, removing images, or importing settings.
* New: Helpful warnings when enabling advanced options like Defer JS or Server Rules.
* New: Plugin UI matches your chosen WordPress admin color scheme.
* Improvement: Faster loading — removed external font dependency.
* Improvement: Better form inputs, loading indicators, and keyboard navigation.
* Improvement: Faster database operations for image processing.
* Security: Fixed several file path security issues.
* Compatibility: Tested up to WordPress 6.9.

= 1.1.4 (2026-04-08) =
* Security: Fixed path traversal vulnerability in the Image Optimisation REST endpoint.
* Security: Added directory traversal protection in URL-to-path resolution.
* Performance: Optimized image queue database writes by caching in memory and flushing once on shutdown.
* Fix: Updated CheckboxOption component to use unique IDs for proper accessibility (label/input association, aria-describedby).

= 1.1.3 (2026-04-07) =
* Fix: Anchored build paths in .distignore to prevent accidental exclusion of vendor files.

= 1.1.2 (2026-04-07) =
* Fix: Cache the Img_Converter instance to reduce PHP overhead during image conversion.
* Fix: Validate and sanitize imported REST API settings before saving.
* Fix: Improve sidebar accessibility and keyboard navigation in the admin UI.
* Update: Use `@wordpress/element` for React rendering compatibility in WordPress.

= 1.1.1 (2026-04-06) =
* Improvement: Optimized JS Defer and Delay loading by caching exclusion lists.
* Improvement: Enhanced backend performance by reducing redundant string parsing.
* Security: Implemented protection against potential directory traversal vulnerabilities.
* Fix: Standardized REST API key sanitization to prevent settings synchronization issues.
* Localization: Added translated ARIA labels for sidebar accessibility.

= 1.1.0 (2026-04-05) =
* Improvement: Visually enhanced the 'File Optimization' settings for easier configuration.
* Improvement: Hardened overall plugin security and input validation.
* Fix: Automatically clear cache when changing permalink settings or switching themes.
* Fix: Prevented unnecessary CSS files from generating on 404 error pages.
* Update: Improved image lazy loading reliability for smoother page rendering.


= 1.0.0 (2024-12-18) =

Initial release with full functionality:
Dashboard overview.
Cache management.
JavaScript, CSS, and HTML optimization.
Advanced image optimisation and lazy loading.
Preloading settings for cache, fonts, and images.
Import/export settings tools.

== Frequently Asked Questions ==

= Will this work with WooCommerce? =
Yes. WooCommerce-specific asset removal is **optional** and off by default. If you enable it, test cart, checkout, and product pages—incorrect URL or handle exclusions can break the storefront.

= Can I use this with another cache plugin (WP Super Cache, LiteSpeed, WP Rocket, etc.)? =
You should run **one** full-page caching solution. This plugin can install a `advanced-cache.php` drop-in when appropriate; if another plugin or your host already manages that file, Performance Optimisation will not replace it and may show an admin notice. Minify/image features may still be usable depending on your stack—test carefully.

= Does this plugin improve Core Web Vitals or PageSpeed Insights? =
It can help when you enable features that address LCP, CLS, and JS blocking (lazy load, minify, preload, modern image formats). Results depend on your theme and other plugins; always measure before and after.

= How do I optimize images using this plugin? =
Go to the Image Optimisation Settings tab, enable image conversion, and choose the format (WebP, AVIF, or both). Click "Optimize Now" to start the process.

= Can I exclude specific JavaScript or CSS files from minification? =
Yes, in the File Optimization Settings tab, use the provided text areas to list files you want to exclude.

= Does the plugin support lazy loading for images? =
Yes, lazy loading can be enabled in the Image Optimisation Settings tab. You can also use SVG placeholders for better performance.

= How can I import/export plugin settings? =
Use the Tools section to export your current settings or import settings from another instance.

== Upgrade Notice ==

= 1.6.0 (2026-04-26) =
Major feature release bringing official Google PageSpeed Insights integration to the WordPress dashboard. Introduces Nginx configuration support, automatic wp-config.php self-healing, and enhanced telemetry with modern compression support (Zstd).

= 1.5.1 (2026-04-23) =
Performance and stability release optimizing the `wppo_img_info` database option for reduced memory overhead and implementing atomic write protection for image metadata.

= 1.5.0 (2026-04-20) =
Introduces the Performance Monitor (high-precision local telemetry engine), System Info Dashboard for real-time environment diagnostics, and a new Developer Mode for granular network timings.

= 1.4.0 (2026-04-18) =
Major stability and feature release introducing Enterprise Redis Support, batched processing architecture for long-running tasks, and a refined Design System v2.1. Includes critical security hardening and AJAX-based session resilience.

= 1.3.0 (2026-04-15) =
Feature release introducing automated database optimization scheduling, comprehensive "Core Tweaks", MutationObserver-based lazy loading, and numerous systemic UI/UX improvements utilizing native WordPress CSS schemas.

= 1.2.3 (2026-04-14) =
Stability and performance release: Fixed a fatal error during activation/admin notices, implemented lazy loading for cache handlers to reduce overhead, and aligned documentation with official directory limits.

= 1.2.1 (2026-04-14) =
Stability and security release with wp-config path resolution fixes, asset handle whitelisting, and improved activation logic for WP_CACHE management.

= 1.2.0 (2026-04-13) =
Major feature release completing the "Cache Core" milestone: .htaccess automation, CDN URL rewriting, and smart cache purging. Includes a full Design System v2.0 with WordPress admin color scheme sync, confirmation dialogs, and polished form controls. Significant security and performance improvements throughout.

= 1.1.4 (2026-04-08) =
Security release with path traversal fixes, image queue performance improvements, and accessibility fixes.

= 1.1.3 (2026-04-07) =
Maintenance release to fix vendor file exclusion in build packages.

= 1.1.2 (2026-04-07) =
Compatibility release ensuring React rendering compatibility with @wordpress/element and sanitized REST API imports.

= 1.1.1 (2026-04-06) =
Minor release with JS performance optimizations and security hardening.

= 1.1.0 (2026-04-05) =
Feature release introducing Database Cleanup tools, Asset Manager monitoring, and a major UI overhaul of File Optimization settings.

= 1.0.0 (2024-12-18) =
Initial release with core performance features.
