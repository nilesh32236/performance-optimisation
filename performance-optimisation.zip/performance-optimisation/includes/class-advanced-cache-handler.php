<?php
/**
 * Advanced_Cache_Handler class for the PerformanceOptimise plugin.
 *
 * Handles the creation and removal of an advanced-cache.php file used for serving cached content.
 *
 * @package PerformanceOptimise\Inc
 * @since 1.0.0
 */

namespace PerformanceOptimise\Inc;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'PerformanceOptimise\Inc\Advanced_Cache_Handler' ) ) {
	/**
	 * Class Advanced_Cache_Handler
	 *
	 * Manages the creation and removal of the advanced-cache.php file.
	 *
	 * @since 1.0.0
	 */
	class Advanced_Cache_Handler {

		/**
		 * Marker inside advanced-cache.php drop-in so we do not overwrite or delete other plugins' files.
		 *
		 * @var string
		 */
		public const DROPIN_MARKER = 'WPPO_ADVANCED_CACHE_DROPIN';

		/**
		 * Path to the advanced-cache.php drop-in.
		 *
		 * @return string
		 */
		public static function get_dropin_path(): string {
			return wp_normalize_path( WP_CONTENT_DIR . '/advanced-cache.php' );
		}

		/**
		 * Whether the existing advanced-cache.php (if any) was created by this plugin.
		 *
		 * @return bool
		 */
		public static function is_our_dropin(): bool {
			global $wp_filesystem;

			$handler_file = self::get_dropin_path();

			if ( ! $wp_filesystem && ! Util::init_filesystem() ) {
				return false;
			}

			if ( ! $wp_filesystem->exists( $handler_file ) ) {
				return false;
			}

			$contents = $wp_filesystem->get_contents( $handler_file );

			if ( ! is_string( $contents ) ) {
				return false;
			}

			if ( false !== strpos( $contents, self::DROPIN_MARKER ) ) {
				return true;
			}

			// Legacy drop-ins from releases before DROPIN_MARKER was added.
			return false !== strpos( $contents, 'is_user_logged_in_without_wp' );
		}

		/**
		 * Another plugin (or host) owns advanced-cache.php; we must not replace it.
		 *
		 * @return bool
		 */
		public static function foreign_dropin_present(): bool {
			global $wp_filesystem;

			$handler_file = self::get_dropin_path();

			if ( ! $wp_filesystem && ! Util::init_filesystem() ) {
				return false;
			}

			if ( ! $wp_filesystem->exists( $handler_file ) ) {
				return false;
			}

			return ! self::is_our_dropin();
		}

		/**
		 * Creates the advanced-cache.php file.
		 *
		 * Generates the file to serve cached content, including gzip versions, and ensures required directories exist.
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public static function create(): void {

			global $wp_filesystem;

			if ( self::foreign_dropin_present() ) {
				return;
			}

			if ( ! $wp_filesystem && ! Util::init_filesystem() ) {
				return;
			}

			$site_url = home_url();

			$handler_code = '<?php' . PHP_EOL .
			'// ' . self::DROPIN_MARKER . PHP_EOL .
			'if ( ! defined( \'ABSPATH\' ) ) {' . PHP_EOL .
			'	exit;' . PHP_EOL .
			'}' . PHP_EOL . PHP_EOL .

			'$site_url       = \'' . $site_url . '\';' . PHP_EOL .
			'$root_directory = $_SERVER[\'DOCUMENT_ROOT\'];' . PHP_EOL .
			'$site_domain    = isset( $_SERVER[\'HTTP_HOST\'] ) ? (string) $_SERVER[\'HTTP_HOST\'] : \'\';' . PHP_EOL .
			'$request_uri    = isset( $_SERVER[\'REQUEST_URI\'] ) ? (string) parse_url( $_SERVER[\'REQUEST_URI\'], PHP_URL_PATH ) : \'\';' . PHP_EOL .

			'if ( strpos( $site_domain, \'..\' ) !== false || strpos( $site_domain, \'/\' ) !== false || strpos( $site_domain, \'\\\\\' ) !== false || strpos( $request_uri, \'..\' ) !== false ) {' . PHP_EOL .
			'	return;' . PHP_EOL .
			'}' . PHP_EOL . PHP_EOL .

			'if ( \'/\' !== substr( $request_uri, -1 ) ) {' . PHP_EOL .
			'	$request_uri .= \'/\';' . PHP_EOL .
			'}' . PHP_EOL . PHP_EOL .

			'$file_path      = WP_CONTENT_DIR . \'/cache/wppo/\' . $site_domain . $request_uri . \'index.html\';' . PHP_EOL .
			'$file_path      = str_replace( \'\\\\\', \'/\', $file_path );' . PHP_EOL .
			'$file_path      = preg_replace( \'#/+#\', \'/\', $file_path );' . PHP_EOL .
			'$file_path      = rtrim( $file_path, \'/\' );' . PHP_EOL .
			'$gzip_file_path = $file_path . \'.gz\';' . PHP_EOL . PHP_EOL .

			'function is_user_logged_in_without_wp( $site_url ) {' . PHP_EOL .
			'	if ( isset( $_COOKIE[ \'wordpress_logged_in_\' . md5( $site_url ) ] ) ) {' . PHP_EOL .
			'		return true;' . PHP_EOL .
			'	}' . PHP_EOL .
			'	return false;' . PHP_EOL .
			'}' . PHP_EOL . PHP_EOL .

			'if ( ! is_user_logged_in_without_wp( $site_url ) &&' . PHP_EOL .
			'	( empty( $_SERVER[\'QUERY_STRING\'] ) )' . PHP_EOL .
			') {' . PHP_EOL .
			'	if ( file_exists( $gzip_file_path ) ) {' . PHP_EOL .
			'		$last_modified_time = filemtime( $gzip_file_path );' . PHP_EOL .
			'		$etag               = md5_file( $gzip_file_path );' . PHP_EOL .
			'		header( \'Last-Modified: \' . gmdate( \'D, d M Y H:i:s\', $last_modified_time ) . \' GMT\' );' . PHP_EOL .
			'		header( \'ETag: "\' . $etag . \'"\' );' . PHP_EOL .
			'		header( \'Content-Type: text/html\' );' . PHP_EOL .
			'		header( \'Content-Encoding: gzip\' );' . PHP_EOL . PHP_EOL .

			'		if ( ( isset( $_SERVER[\'HTTP_IF_MODIFIED_SINCE\'] ) && strtotime( $_SERVER[\'HTTP_IF_MODIFIED_SINCE\'] ) >= $last_modified_time ) ||' . PHP_EOL .
			'		( isset( $_SERVER[\'HTTP_IF_NONE_MATCH\'] ) && trim( $_SERVER[\'HTTP_IF_NONE_MATCH\'] ) === $etag ) ) {' . PHP_EOL .
			'			header( \'HTTP/1.1 304 Not Modified\' );' . PHP_EOL .
			'			header( \'Connection: close\' );' . PHP_EOL .
			'			exit;' . PHP_EOL .
			'		}' . PHP_EOL . PHP_EOL .

			'		readfile( $gzip_file_path );' . PHP_EOL .
			'		exit;' . PHP_EOL .
			'	} elseif ( file_exists( $file_path ) ) {' . PHP_EOL .
			'		$last_modified_time = filemtime( $file_path );' . PHP_EOL .
			'		$etag               = md5_file( $file_path );' . PHP_EOL .
			'		header( \'Last-Modified: \' . gmdate( \'D, d M Y H:i:s\', $last_modified_time ) . \' GMT\' );' . PHP_EOL .
			'		header( \'ETag: "\' . $etag . \'"\' );' . PHP_EOL .
			'		header( \'Content-Type: text/html\' );' . PHP_EOL . PHP_EOL .

			'		if ( ( isset( $_SERVER[\'HTTP_IF_MODIFIED_SINCE\'] ) && strtotime( $_SERVER[\'HTTP_IF_MODIFIED_SINCE\'] ) >= $last_modified_time ) ||' . PHP_EOL .
			'		( isset( $_SERVER[\'HTTP_IF_NONE_MATCH\'] ) && trim( $_SERVER[\'HTTP_IF_NONE_MATCH\'] ) === $etag ) ) {' . PHP_EOL .
			'			header( \'HTTP/1.1 304 Not Modified\' );' . PHP_EOL .
			'			header( \'Connection: close\' );' . PHP_EOL .
			'			exit;' . PHP_EOL .
			'		}' . PHP_EOL . PHP_EOL .

			'		readfile( $file_path );' . PHP_EOL .
			'		exit;' . PHP_EOL .
			'	}' . PHP_EOL .
			'}' . PHP_EOL;

			// Write the handler file in the wp-content directory as advanced-cache.php.
			$create_file = $wp_filesystem->put_contents( wp_normalize_path( WP_CONTENT_DIR . '/advanced-cache.php' ), $handler_code, FS_CHMOD_FILE );
		}

		/**
		 * Removes the advanced-cache.php file.
		 *
		 * Deletes the advanced-cache.php file if it exists.
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public static function remove(): void {
			global $wp_filesystem;

			$handler_file = self::get_dropin_path();

			if ( ! Util::init_filesystem() ) {
				return;
			}

			if ( ! $wp_filesystem->exists( $handler_file ) ) {
				return;
			}

			if ( ! self::is_our_dropin() ) {
				return;
			}

			$wp_filesystem->delete( $handler_file );
		}
	}
}
